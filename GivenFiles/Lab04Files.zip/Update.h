#ifndef UPDATE_H
#define UPDATE_H

class Update
{
   private:

   public:
      Update() {}
      virtual ~Update() {}
      virtual void update() = 0;
};

#endif
